CloverLeaf_OpenMP4
==================

An OpenMP 4.0 version of CloverLeaf

Work in progress. Initial attempt.
